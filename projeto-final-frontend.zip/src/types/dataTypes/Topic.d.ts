import { UUID } from "crypto";

interface Topic{
    Id: UUID;
    Title: string;
    Author : string
}