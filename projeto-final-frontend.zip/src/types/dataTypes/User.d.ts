interface User {
    name: string;
    picture: string;
    birthdate: string; // You might want to use a Date object, but for simplicity, I'm using string here
    email: string;
  }
  
  interface UserLogin{
    login: string;
    password: string;
  }