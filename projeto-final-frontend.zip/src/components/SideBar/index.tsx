import SideBarCSS from "@/components/SideBar/SideBar.module.css";
interface SideBarProps{
    
}


const SideBar = () => {
    return <div className={SideBarCSS.main}>
        <ul>
            <li>
                1
            </li>
            <li>
                2
            </li>
            <li>
                3
            </li>
        </ul>
    </div>   
}

export default SideBar;